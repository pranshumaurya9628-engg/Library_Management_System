class Config:
    SECRET_KEY = "library-management-secret-key"

    DB_HOST = "localhost"
    DB_PORT = 3306
    DB_NAME = "library_management"
    DB_USER = "root"
    DB_PASSWORD = "Enter your sql passward"

    FINE_PER_DAY = 5