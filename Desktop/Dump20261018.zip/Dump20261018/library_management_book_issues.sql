-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: library_management
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book_issues`
--

DROP TABLE IF EXISTS `book_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_issues` (
  `issue_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `book_id` int NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `status` enum('Issued','Returned') DEFAULT 'Issued',
  PRIMARY KEY (`issue_id`),
  KEY `student_id` (`student_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `book_issues_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `book_issues_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_issues`
--

LOCK TABLES `book_issues` WRITE;
/*!40000 ALTER TABLE `book_issues` DISABLE KEYS */;
INSERT INTO `book_issues` VALUES (1,2,1,'2026-08-14','2026-08-28','2026-08-15','Returned'),(2,2,1,'2026-08-15','2026-08-29','2026-08-15','Returned'),(3,2,2,'2026-08-15','2026-08-29','2026-08-15','Returned'),(4,2,2,'2026-08-15','2026-08-29','2026-08-15','Returned'),(5,2,3,'2026-08-15','2026-08-29','2026-08-15','Returned'),(6,3,1,'2026-08-15','2026-08-09','2026-08-15','Returned'),(7,2,3,'2026-08-15','2026-08-10','2026-08-15','Returned'),(8,2,1,'2026-08-15','2026-08-10','2026-08-15','Returned'),(9,5,3,'2026-08-17','2026-08-31','2026-08-17','Returned'),(10,9,3,'2026-08-24','2026-09-07','2026-08-26','Returned'),(11,14,5,'2026-08-26','2026-09-09','2026-08-26','Returned'),(12,14,1,'2026-08-26','2026-09-09','2026-08-26','Returned'),(13,14,5,'2026-08-26','2026-08-20','2026-08-26','Returned'),(14,14,2,'2026-08-26','2026-09-09','2026-08-26','Returned'),(15,14,5,'2026-08-27','2026-09-10','2026-08-27','Returned'),(16,15,3,'2026-09-07','2026-09-21','2026-09-10','Returned'),(17,15,5,'2026-09-09','2026-09-23','2026-09-09','Returned'),(18,15,6,'2026-09-25','2026-10-09','2026-09-25','Returned'),(19,15,2,'2026-10-03','2026-10-17',NULL,'Issued'),(20,15,3,'2026-10-03','2026-10-17',NULL,'Issued'),(21,15,5,'2026-10-03','2026-10-17','2026-10-18','Returned'),(22,16,7,'2026-10-03','2026-10-17','2026-10-14','Returned'),(23,17,8,'2026-10-03','2026-10-17','2026-10-03','Returned');
/*!40000 ALTER TABLE `book_issues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-18 21:13:02
