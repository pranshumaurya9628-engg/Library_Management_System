-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: library_management
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `student_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `roll_no` varchar(50) NOT NULL,
  `course` varchar(100) DEFAULT NULL,
  `branch` varchar(100) DEFAULT NULL,
  `library_id` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `roll_no` (`roll_no`),
  UNIQUE KEY `library_id` (`library_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (2,'Pranshu Maurya','0082','B. Tech','CSE','250063','pranshumaurya00@gmail.com','7081126045',0),(3,'Rishu Mishra','2504230100096','B.Tech','CSE','250100','rishumishra96@gmail.com','9699654551',0),(5,'Mohd.Shahveez','2504230100044','B.Tech','CSE','2501133','shahvezz36@gmail.com','2252253612',0),(6,'Rahul Kumar','101','BCA','CS','LIB101','rahul101@gmail.com','7081126052',0),(7,'Prnshu Maurya','202','B.Tech','CSE','LIB202','pranshumaurya2525@gmail.com','3625147485',0),(8,'Pranshu Maurya','205','B.tech','CSE','LIB001','pranshumaurya9628@gmail.com','8187977720',0),(9,'Pranshu','303','BCA','CSe','LIB303','pranshu303@gmail.com','9876543210',0),(10,'Anshu Maurya','8187','B tech','CSE','1004','anshu8187@gmail.com','8187100425',0),(11,'Pranshu','6535','BTECh','CSE','2536','pranshu@gmail.com','6393140650',0),(12,'Rudra','25042','BCA','CS','LIB042','rudra2026@gmail.com','3566886578',0),(13,'Pranshsu','2504230100082','B.tech','CSE','LIB123','pranshu123@gmail.com','2214844994',0),(14,'Pranshu Maurya','1302','BCA','CS','LIB5501','pranshu130@gmail.com','6393140625',0),(15,'Pranshu','250423010000000','B.Tech','CSE','LIB005','pranshu9628@gmail.com','2519159485',1),(16,'Ashok','250423010005','B.tech','CSE','LIB512','ashok123@gmail.com','9875485523',1),(17,'Himanshu','25011154149','B.tech','AIML','LIB52','himanshu@gmail.com','2518214816',1);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-18 21:13:03
